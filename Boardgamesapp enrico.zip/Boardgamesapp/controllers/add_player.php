<?php
/**
 * Created by: stephanhoeksema 2018
 * phpoop
 */

var_dump($app['database']);