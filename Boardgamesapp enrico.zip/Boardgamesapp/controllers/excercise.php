<?php
/**
 * Created by: stephanhoeksema 2018
 * phpoop
 */


/**
 * @internal view index.php
 */
require 'views/excercise.view.php';