<?php require 'partials/head.php'; ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-10 offset-1">
        </div> <!-- End div greeting -->
        <hr>
        <div class="col-10 offset-1">
            <h4>Battles</h4>

        </div><!-- End div - battles -->
        <hr>
        <div class="col-10 offset-1">

        </div><!-- End div - class Player-->
    </div> <!-- End div row -->
</div> <!-- End container -->
<?php require 'partials/foot.php'; ?>