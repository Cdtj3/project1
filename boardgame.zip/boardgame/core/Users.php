<?php
/**
 * Created by: stephanhoeksema 2018
 * phpoop
 */

class Users
{
    public $fname;
    public $email;
    public $nickname;

    public static function gameStatus()
    {
        return " Deze speler is erg goed!";
    }
}