<?php require ('server.php');

if (isset($_POST['reg_user'])) {



    $fname = $_POST['fname'];

    $lname = $_POST['lname'];

    $email = $_POST['email'];

    $mobile = $_POST['mobile'];

    $password = $_POST['password'];





    // register user if there are no errors in the form

    if (count($errors) == 0) {

//        $password = $password_1;

        $password = hash("sha256",$password);

        $query = $conn->prepare("INSERT INTO users (fname, lname, email, mobile, password) 

                                            VALUES ('$fname','$lname','$email','$mobile','$password')");

        $query->execute();




    }

}