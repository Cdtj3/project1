<?php
// Step 1: Create a variable named 'programmer' and set it's value equal to 'Ada Lovelace'

// Step 2: Create another variable named 'year' and set it's value equal to '1843'

// Step 3: Replace <programmer> in the 'message' string with the variable 'programmer', and replace <year> in the 'message' string with the variable 'year'.

$message = "Recognized as the first computer programmer, <programmer> wrote the first computer algorithm in <year>.";

// Step 4: Display the 'message' string to the screen