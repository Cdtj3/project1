<?php
/**
* Connection to database
*/
try{
$database = new PDO(
        'mysql:host=localhost:3306;dbname=spelletjes',
        'root',
        'root'
);
} catch (PDOException $e) {
    echo $e->getMessage();
}


$stmt = $database->prepare('select * from users');
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

//var_dump($results);

foreach ($results as $result){

    foreach ($result as $key => $value){

        echo $key . ' ' . $value . '<br>';
    }

};