<?php
//if ($_SERVER[HTTP_HOST] == 'localhost:3306'){
/**
 * GET routes
 */
$router->get('','controllers/index.php');
$router->get('home', 'controllers/index.php');
$router->get('players', 'controllers/players.php');
$router->get('games', 'controllers/games.php');
$router->get('users', 'controllers/users.php');
$router->get('battles', 'controllers/battles.php');
$router->get('excercise', 'controllers/excercise.php');

/**
 * POST routes
 */

$router->post('add_user', 'controllers/add_player.php');
$router->post('delete_user', 'controllers/delete_player.php');
$router->post('upd_user', 'controllers/apd_player.php');
$router->post('add_player', 'controllers/player.php');

//}
//else {
//
//    $router->get('~S1135542/P1_00APP_opdracht' 'controllers/index.php');
//    $router->get('~S1135542/P1_00APP_opdracht/home' 'controllers/index.php');
//    $router->get('~S1135542/P1_00APP_opdracht/players' 'controllers/players.php');
//    $router->get('~S1135542/P1_00APP_opdracht/games' 'controllers/games.php');
//    $router->get('~S1135542/P1_00APP_opdracht/users' 'controllers/users.php');
//    $router->get('~S1135542/P1_00APP_opdracht/battles' 'controllers/battles.php');
//    $router->get('~S1135542/P1_00APP_opdracht/excercise' 'controllers/excercise.php');
//
//
//    $router->post('~S1135542/P1_00APP_opdracht/users/add_user', 'controllers/add_player.php');
//    $router->post('~S1135542/P1_00APP_opdracht/users/delete_user', 'controllers/delete_player.php');
//    $router->post('~S1135542/P1_00APP_opdracht/users/upd_user', 'controllers/apd_player.php');
//    $router->post('~S1135542/P1_00APP_opdracht/users/add_player', 'controllers/player.php');
//
//}
