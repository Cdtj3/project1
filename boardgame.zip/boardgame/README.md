# wf-oopphp
Course oop php until database connection

Change config file and routes to match your server
