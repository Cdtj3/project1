<?php
//session_start();
//
//// variable declaration
//$games = "";
//
//
//// connect to database
//$db = mysqli_connect('localhost:3307', 'root', 'root', 'boardgame');
//
//// REGISTER USER
//if (isset($_POST['reg_games'])) {
//    // receive all input values from the form
//    $games = mysqli_real_escape_string($db, $_POST['games']);
//
//?><!--;-->