<?php
/**
 * Created by: stephanhoeksema 2018
 * phpoop
 */


require 'views/games.view.php';